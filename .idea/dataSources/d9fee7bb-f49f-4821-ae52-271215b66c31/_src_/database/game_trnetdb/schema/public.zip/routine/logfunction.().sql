create function logfunction() returns trigger
LANGUAGE plpgsql
AS $$
begin
IF (TG_OP = 'DELETE') THEN
insert into log (username,date,name,operation,price,genre_id,logo,game_id) values (user,now(),OLD.name,'D',OLD.price,OLD.genre_id,OLD.logo,OLD.id);
return OLD;
ELSIF(TG_OP = 'UPDATE') THEN
insert into log (username,date,name,operation,price,genre_id,logo,game_id) values (user,now(),OLD.name,'U',OLD.price,OLD.genre_id,OLD.logo,NEW.id);
return OLD;
ELSIF (TG_OP = 'INSERT') THEN
insert into log (username,date,name,operation,price,genre_id,logo,game_id) values(user,now(),NEW.name,'I',NEW.price,NEW.genre_id,NEW.logo,NEW.id);
return NEW;
end if;
return null;
end;
$$;
